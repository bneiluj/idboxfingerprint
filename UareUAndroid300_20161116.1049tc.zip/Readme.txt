  -------------------------------------------------------------------
                           Crossmatch

         U.are.U SDK for Android with TouchChip Support v.3.0.0
                        
                            Readme File
                           
                           November 22, 2016
                                
  --------------------------------------------------------------------
           (c) 2016 Crossmatch, Inc. All Rights Reserved. 


This document provides late-breaking or other information that supplements the Crossmatch U.are.U SDK for Android documentation.


-------------------------
How to Use This Document
-------------------------

This document can be viewed with a text editor like "vi" running under Linux.

or

To view the Readme file on-screen in Windows Notepad, maximize the Notepad window. On the Format menu, click Word Wrap. To print the Readme file, open it in Notepad or another word processor, and then use the Print command on the File menu.


---------
CONTENTS
---------

1.   INSTALLATION

2.   COMPATIBILITY

3.   SYSTEM REQUIREMENTS

4.   RELEASE NOTES

5.   KNOWN ISSUES
     
6.   SUPPORT AND FEEDBACK


----------------
1. INSTALLATION
----------------

CAUTION: If you are installing the U.are.U SDK for Android with TouchChip Support
on a device where the edition without TouchChip Support was previously installed, 
remove the Java sample (DigitalPersona U are U SDK Sample) from the device before the new installation.

There are two steps to the installation.
1. Installing on the development system.
2. Installing on the device (the target hardware).
 
Installing on the Development System (Intel-based Linux development system).
1. Unpack CM-UareU-3.0.0-<date,build>.tar.gz into a directory.
2. Go to the directory where you unpacked the files.
3. Run setup. 
4. Follow the prompts as they appear.

Installing on the Target Hardware.
1. Enable USB debugging mode by navigating on your device�s display to Settings->Developer Options->Enable USB debugging.
2. Connect the target hardware platform to the development system.
3. Establish an adb connection with the device.
4. Run: adb install <UareU SDK folder>/urusdk/android/Android/Samples/bin/UareUSampleJava.apk 

-----------------
2. COMPATIBILITY
-----------------

- Crossmatch U.are.U SDK for Android contains the 6.0.1 and 7.0.0 recognition engines, 3.0.71 driver libraries. And is compatible with Crossmatch fingerprint devices: U.are.U 4500, 4500 UID, 5100, 5160, 5200 and 5300, EikonTouch 510, 710 and Eikon II.



-----------------------
3. SYSTEM REQUIREMENTS
-----------------------

Intel based.
- Pentium-class processor
- 128 MB RAM or the minimum amount required to run your Linux operating system
- GNU Compiler Collection (GCC), G++, GNU make and kernel-devel
- OpenJDK and/or Oracle JDK 6 or 7.

The Android-based device must have Android 4.4.0 or better installed (API level 19 or better) and the UVC (also known as Video4Linux) kernel driver enabled. A USB port in host mode is required. 

-----------------
4. RELEASE NOTES
-----------------

- We have provided support for one of the most widely adopted off-the-shelf Android platforms, the Nexus 7 (16GB Wi-Fi, 32GB Wi-Fi, 32GB Wi-Fi + Mobile data). You can use this platform to quickly develop prototypes allowing you to test your ideas and share them with your customer before you develop your own solution. For creating custom Android solutions we recommend using a development environment that allows root access and the ability to configure the kernel. 
- This release Provides interface for:
  C++
  Java
- This release supports U.are.U 4500 reader and module
- Root privileges on the Android device are not required to run Java application.

----------------
5. KNOWN ISSUES
----------------

- Devices based on Spreadtrum SC7730 and Spreadtrum SC7731G SoC are not compatible with 5xxx series readers.
- Sample may crash if device goes to sleep and removes power from the USB port.
- Maximum number of readers available with the Java Apk depends on the target hardware and the target Operating System version.
- Powered USB Hub is recommended if you experience the fingerprint reader losing connection with the tablet often.
- If you experience "DP error: 0x1f The reader is not working properly", you should reselect the reader and try again.
- �Warning: linker: libdpfj.so and libdpfpdd5000.so has text relocations." will display if running C/C++ on Nexus 4.4.2.
- UareUCaptureOnly: when select 4. Asynchronous Capture item got DP error 0x14.

------------------------
6. SUPPORT AND FEEDBACK
------------------------

We provide fee-based support packages and support for registered users at our web site http://www.digitalpersona.com.
Free technical support is available through the DigitalPersona Developer Connection forums at www.digitalpersona.com/webforums.
If you have suggestions for future product releases or require technical support for the beta version of the SDK, send email to techsupport@digitalpersona.com. In the subject line, type "U.are.U SDK for Android 3.0.0 support."
You can also purchase a Developer Support package at our web store: https://store2.esellerate.net/store/checkout/CustomLayout.aspx?s=STR1045285899&pc=&page=OnePageCatalog.htm
